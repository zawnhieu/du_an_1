<footer>
    <div class="footer_logo">
        <a href="index.php"><img src="./img/Olive Green Pink Modern Minimalist Company Logo (1).png" alt=""></a>
    </div>
    <div class="center">
        <h3>Địa chỉ</h3>
        <div class="right_icon">
            <p>Miền Bắc</p>
            <a href="#">
                <i class="fa-solid fa-location-dot"></i>
                <span>Số 40, P.Nguyên xá, P.Minh Khai, Q.Bắc Từ Liêm</span>
            </a>
        </div>
        <div class="right_icon">
            <p>Miền Trung</p>
            <a href="#">
                <i class="fa-solid fa-location-dot"></i>
                <span>Số 40, P.Nguyên xá, P.Minh Khai, Q.Bắc Từ Liêm</span>
            </a>
        </div>
        <div class="right_icon">
            <p>Miền Nam</p>
            <a href="#">
                <i class="fa-solid fa-location-dot"></i>
                <span>Số 40, P.Nguyên xá, P.Minh Khai, Q.Bắc Từ Liêm</span>
            </a>
        </div>

    </div>
    <div class="right">
        <h3>Trợ giúp</h3>
        <div class="right_icon">
            <a href="#">
                <i class="fa-brands fa-facebook"></i>
                <span>Facebook</span>
            </a>
        </div>
        <div class="right_icon">
            <a href="#">
                <i class="fa-solid fa-phone"></i>
                <span>0123.789.888</span>
            </a>
        </div>
        <div class="right_icon">
            <a href="#">
                <i class="fa-brands fa-tiktok"></i>
                <span>TikTok</span>
            </a>
        </div>
        <div class="right_icon">
            <a href="#">
                <i class="fa-brands fa-instagram"></i>
                <span>Instagram</span>
            </a>
        </div>
    </div>
</footer>
<script src="./js/main.js"></script>
</body>

</html>